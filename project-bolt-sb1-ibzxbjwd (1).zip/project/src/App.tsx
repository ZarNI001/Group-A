import React, { useState } from 'react';
import { Compass, BookOpen, Target, Award, ChevronRight, Briefcase } from 'lucide-react';

type CareerPath = {
  title: string;
  description: string;
  skills: string[];
  image: string;
};

function App() {
  const [selectedPath, setSelectedPath] = useState<CareerPath | null>(null);

  const careerPaths: CareerPath[] = [
    {
      title: "Software Development",
      description: "Build the future through code. Learn programming languages, software architecture, and development best practices.",
      skills: ["JavaScript", "Python", "System Design", "Problem Solving"],
      image: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=800"
    },
    {
      title: "Data Science",
      description: "Transform data into insights. Master statistics, machine learning, and data visualization.",
      skills: ["Python", "Statistics", "Machine Learning", "SQL"],
      image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=800"
    },
    {
      title: "UX Design",
      description: "Create amazing user experiences. Learn design thinking, user research, and prototyping.",
      skills: ["UI Design", "User Research", "Prototyping", "Design Systems"],
      image: "https://images.unsplash.com/photo-1586717791821-3f44a563fa4c?auto=format&fit=crop&w=800"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Compass className="h-8 w-8 text-indigo-600" />
            <h1 className="text-2xl font-bold text-gray-900">CareerCompass</h1>
          </div>
          <nav className="flex space-x-4">
            <a href="#paths" className="text-gray-600 hover:text-gray-900">Career Paths</a>
            <a href="#resources" className="text-gray-600 hover:text-gray-900">Resources</a>
            <a href="#goals" className="text-gray-600 hover:text-gray-900">Goal Setting</a>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center">
          <h2 className="text-4xl font-extrabold text-gray-900 sm:text-5xl">
            Navigate Your Career Journey
          </h2>
          <p className="mt-4 text-xl text-gray-600">
            Discover your path, set goals, and build the skills you need to succeed
          </p>
        </div>
      </div>

      {/* Career Paths */}
      <section id="paths" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h3 className="text-2xl font-bold text-gray-900 mb-8">Popular Career Paths</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {careerPaths.map((path) => (
            <div
              key={path.title}
              className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300"
              onClick={() => setSelectedPath(path)}
            >
              <img src={path.image} alt={path.title} className="w-full h-48 object-cover" />
              <div className="p-6">
                <h4 className="text-xl font-semibold text-gray-900 mb-2">{path.title}</h4>
                <p className="text-gray-600 mb-4">{path.description}</p>
                <div className="flex items-center text-indigo-600 hover:text-indigo-700">
                  Learn More <ChevronRight className="h-4 w-4 ml-1" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section className="bg-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-indigo-100 rounded-full p-3 w-12 h-12 mx-auto mb-4 flex items-center justify-center">
                <Target className="h-6 w-6 text-indigo-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Set Clear Goals</h3>
              <p className="text-gray-600">Define your career objectives and create actionable plans</p>
            </div>
            <div className="text-center">
              <div className="bg-indigo-100 rounded-full p-3 w-12 h-12 mx-auto mb-4 flex items-center justify-center">
                <BookOpen className="h-6 w-6 text-indigo-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Learn Skills</h3>
              <p className="text-gray-600">Access curated resources and training materials</p>
            </div>
            <div className="text-center">
              <div className="bg-indigo-100 rounded-full p-3 w-12 h-12 mx-auto mb-4 flex items-center justify-center">
                <Award className="h-6 w-6 text-indigo-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Track Progress</h3>
              <p className="text-gray-600">Monitor your achievements and stay motivated</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-indigo-700 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Ready to Start Your Journey?</h2>
          <p className="text-indigo-100 mb-8">Create your personalized career development plan today</p>
          <button className="bg-white text-indigo-700 px-6 py-3 rounded-lg font-semibold hover:bg-indigo-50 transition-colors duration-300">
            Get Started
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-300 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Briefcase className="h-6 w-6" />
              <span className="font-semibold">CareerCompass</span>
            </div>
            <div className="text-sm">
              © 2025 CareerCompass. All rights reserved.
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;